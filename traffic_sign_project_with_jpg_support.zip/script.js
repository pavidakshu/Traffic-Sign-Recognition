const knownSigns = {
  "stop.png": "Stop Sign",
  "no_entry.png": "No Entry",
  "no_parking.png": "No Parking Zone",
  "no_stopping.png": "No Stopping Zone",
  "speed_limit_30.png": "Speed Limit 30"
};

document.getElementById('imageInput').addEventListener('change', function (e) {
  const file = e.target.files[0];
  const preview = document.getElementById('preview');
  const resultText = document.getElementById('resultText');

  if (file) {
    let fileName = file.name.toLowerCase();
    if (fileName.endsWith('.jpg')) {
      fileName = fileName.replace('.jpg', '.png');
    }

    preview.src = URL.createObjectURL(file);
    preview.style.display = 'block';

    const result = knownSigns[fileName] || "Unknown Sign";
    resultText.textContent = "Detected: " + result;

    const speech = new SpeechSynthesisUtterance(result);
    window.speechSynthesis.speak(speech);
  }
});
